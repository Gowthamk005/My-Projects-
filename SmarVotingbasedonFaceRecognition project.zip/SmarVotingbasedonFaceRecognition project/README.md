# Smart Voting System - Face Recognition Based

A secure, transparent, and accessible voting system powered by cutting-edge face recognition technology, built with Java Spring Boot.

## 🚀 Features

- **Face Recognition Authentication**: Secure biometric verification for voting
- **Voter Registration**: Complete voter registration with identity verification
- **Admin Dashboard**: Manage elections, candidates, and voter verification
- **Real-time Results**: Live election results with vote counts
- **Secure Voting**: One person, one vote guarantee with face verification
- **Audit Trail**: Complete logging of all verification attempts

## 🛠️ Technology Stack

| Component | Technology |
|-----------|------------|
| **Backend** | Java 21, Spring Boot 3.2.2 |
| **Security** | Spring Security, JWT |
| **Database** | H2 (Dev), MySQL (Prod) |
| **ORM** | Spring Data JPA, Hibernate 6 |
| **Frontend** | Thymeleaf, Bootstrap 5.3, Font Awesome |
| **Build Tool** | Maven 3.9+ |

## 📋 Prerequisites

1. **JDK 21** - Download from [Oracle](https://www.oracle.com/java/technologies/downloads/#java21) or use [SDKMAN](https://sdkman.io/)
2. **Maven 3.9+** - Download from [Apache Maven](https://maven.apache.org/download.cgi)
3. **IDE** - IntelliJ IDEA (recommended) or VS Code with Java Extension Pack

## 🔧 Installation & Setup

### 1. Clone the Repository
```bash
cd d:\projects\nitroware\SmarVotingbasedonFaceRecognition
```

### 2. Install Maven (if not installed)
Download from [https://maven.apache.org/download.cgi](https://maven.apache.org/download.cgi)

Extract and add to PATH:
```powershell
# Add to System Environment Variables
# MAVEN_HOME = C:\path\to\apache-maven-3.9.x
# Add to PATH: %MAVEN_HOME%\bin
```

### 3. Build the Project
```bash
mvn clean install
```

### 4. Run the Application
```bash
mvn spring-boot:run
```

Or with Java directly:
```bash
mvn clean package
java -jar target/smart-voting-1.0.0.jar
```

### 5. Access the Application
Open your browser and navigate to:
- **Home**: http://localhost:8080
- **H2 Console**: http://localhost:8080/h2-console (JDBC URL: `jdbc:h2:file:./data/smartvoting`)

## 🔐 Default Credentials

| Role | Email | Password |
|------|-------|----------|
| **Admin** | admin@smartvoting.com | admin123 |

## 📁 Project Structure

```
SmarVotingbasedonFaceRecognition/
├── pom.xml                                 # Maven configuration
├── src/
│   ├── main/
│   │   ├── java/com/nitroware/smartvoting/
│   │   │   ├── SmartVotingApplication.java  # Main entry point
│   │   │   ├── config/                       # Configuration classes
│   │   │   │   ├── SecurityConfig.java
│   │   │   │   ├── WebConfig.java
│   │   │   │   └── DataInitializer.java
│   │   │   ├── controller/                   # REST & Web controllers
│   │   │   │   ├── AuthController.java
│   │   │   │   ├── VoterController.java
│   │   │   │   ├── AdminController.java
│   │   │   │   └── PageController.java
│   │   │   ├── dto/                          # Data Transfer Objects
│   │   │   ├── exception/                    # Exception handlers
│   │   │   ├── model/                        # JPA Entities
│   │   │   │   ├── User.java
│   │   │   │   ├── Voter.java
│   │   │   │   ├── Election.java
│   │   │   │   ├── Candidate.java
│   │   │   │   └── Vote.java
│   │   │   ├── repository/                   # Spring Data repositories
│   │   │   ├── security/                     # Security components
│   │   │   │   ├── JwtTokenProvider.java
│   │   │   │   ├── JwtAuthenticationFilter.java
│   │   │   │   └── CustomUserDetailsService.java
│   │   │   └── service/                      # Business logic
│   │   │       ├── AuthService.java
│   │   │       ├── VoterService.java
│   │   │       ├── ElectionService.java
│   │   │       ├── VotingService.java
│   │   │       └── FaceRecognitionService.java
│   │   └── resources/
│   │       ├── application.yml               # Application configuration
│   │       ├── static/
│   │       │   ├── css/style.css
│   │       │   └── js/app.js
│   │       └── templates/                    # Thymeleaf templates
│   │           ├── home.html
│   │           ├── login.html
│   │           ├── register.html
│   │           ├── voter/
│   │           │   ├── dashboard.html
│   │           │   ├── face-registration.html
│   │           │   └── vote.html
│   │           └── admin/
│   │               ├── dashboard.html
│   │               ├── elections.html
│   │               ├── voters.html
│   │               └── candidates.html
│   └── test/                                 # Unit tests
└── uploads/                                  # Uploaded files (generated)
    ├── faces/                                # Voter face images
    └── candidates/                           # Candidate photos
```

## 🔄 Workflow

### For Voters:
1. **Register** - Create account with Voter ID and Aadhaar
2. **Face Registration** - Register face using webcam
3. **Wait for Verification** - Admin verifies identity
4. **Vote** - Once approved, cast vote with face verification

### For Admins:
1. **Login** - Access admin dashboard
2. **Verify Voters** - Approve or reject voter registrations
3. **Manage Elections** - Create, start, end elections
4. **Add Candidates** - Add candidates to elections
5. **Publish Results** - Publish election results

## 🔌 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new voter |
| POST | `/api/auth/login` | Login and get JWT |
| GET | `/api/auth/me` | Get current user |

### Voter
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/voter/profile` | Get voter profile |
| POST | `/api/voter/register-face-base64` | Register face (Base64) |
| POST | `/api/voter/verify-face` | Verify face |
| GET | `/api/voter/elections/active` | Get active elections |
| POST | `/api/voter/vote` | Cast vote |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/dashboard` | Get dashboard stats |
| GET | `/api/admin/voters` | Get all voters |
| POST | `/api/admin/voters/{id}/approve` | Approve voter |
| POST | `/api/admin/voters/{id}/reject` | Reject voter |
| POST | `/api/admin/elections` | Create election |
| POST | `/api/admin/elections/{id}/start` | Start election |
| POST | `/api/admin/elections/{id}/end` | End election |
| POST | `/api/admin/candidates` | Add candidate |

## ⚙️ Configuration

### Production Database (MySQL)
Update `application.yml`:
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/smart_voting
    username: your_username
    password: your_password
    driver-class-name: com.mysql.cj.jdbc.Driver
  jpa:
    hibernate:
      ddl-auto: update
    properties:
      hibernate:
        dialect: org.hibernate.dialect.MySQL8Dialect
```

### Face Recognition Service
For production, integrate with a Python face recognition microservice:
```yaml
app:
  face-recognition:
    service-url: http://localhost:5000
    confidence-threshold: 0.6
```

## 🔒 Security Features

- **JWT Authentication** - Stateless token-based authentication
- **BCrypt Password Encoding** - Secure password hashing
- **CSRF Protection** - Cross-Site Request Forgery protection
- **Role-Based Access Control** - Admin, Voter, Election Officer roles
- **Face Verification Logging** - Audit trail for all verification attempts

## 📝 License

This project is developed by **Nitroware**.

## 🤝 Support

For support and queries:
- Email: support@nitroware.com
- Documentation: [Project Wiki](#)

---

**Built with ❤️ by Nitroware**
