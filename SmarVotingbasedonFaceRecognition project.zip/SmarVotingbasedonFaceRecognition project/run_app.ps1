$ErrorActionPreference = "Stop"
$mavenVersion = "3.9.9"
$mavenDownloadUrl = "https://dlcdn.apache.org/maven/maven-3/$mavenVersion/binaries/apache-maven-$mavenVersion-bin.zip"
$installDir = "$env:USERPROFILE\.maven_dist"
$mavenHome = "$installDir\apache-maven-$mavenVersion"

# Check if already installed
if (-not (Test-Path "$mavenHome\bin\mvn.cmd")) {
    Write-Host "Installing Maven $mavenVersion to $installDir..."
    if (-not (Test-Path $installDir)) { New-Item -ItemType Directory -Force -Path $installDir | Out-Null }
    $zipFile = "$installDir\maven.zip"
    try {
        Invoke-WebRequest -Uri $mavenDownloadUrl -OutFile $zipFile
    } catch {
        Write-Error "Failed to download Maven. Please check your internet connection or the URL."
        exit 1
    }
    Expand-Archive -Path $zipFile -DestinationPath $installDir -Force
    Remove-Item $zipFile
}

# Add to PATH for this process
$env:PATH = "$mavenHome\bin;$env:PATH"
$env:MAVEN_HOME = $mavenHome

# Run the app
Write-Host "Starting Spring Boot Application..."
mvn spring-boot:run
