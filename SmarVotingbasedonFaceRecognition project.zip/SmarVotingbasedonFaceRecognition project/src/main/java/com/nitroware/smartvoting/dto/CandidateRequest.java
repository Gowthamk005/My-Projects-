package com.nitroware.smartvoting.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CandidateRequest {

    @NotBlank(message = "Candidate name is required")
    private String name;

    @NotBlank(message = "Party name is required")
    private String partyName;

    private String partySymbol;

    private String biography;

    private String qualification;

    private Integer age;

    @NotNull(message = "Election ID is required")
    private Long electionId;

    private String constituency;
}
