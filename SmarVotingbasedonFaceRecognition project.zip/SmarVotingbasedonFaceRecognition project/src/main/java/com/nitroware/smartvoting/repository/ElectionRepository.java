package com.nitroware.smartvoting.repository;

import com.nitroware.smartvoting.model.Election;
import com.nitroware.smartvoting.model.ElectionStatus;
import com.nitroware.smartvoting.model.ElectionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ElectionRepository extends JpaRepository<Election, Long> {
    
    List<Election> findByStatus(ElectionStatus status);
    
    List<Election> findByType(ElectionType type);
    
    @Query("SELECT e FROM Election e WHERE e.status = 'ACTIVE'")
    List<Election> findActiveElections(@Param("now") LocalDateTime now);
    
    @Query("SELECT e FROM Election e WHERE e.status = 'UPCOMING' AND e.startDate > :now")
    List<Election> findUpcomingElections(@Param("now") LocalDateTime now);
    
    @Query("SELECT e FROM Election e WHERE e.status = 'COMPLETED' OR e.endDate < :now")
    List<Election> findCompletedElections(@Param("now") LocalDateTime now);
    
    List<Election> findByConstituency(String constituency);
    
    @Query("SELECT e FROM Election e WHERE e.resultsPublished = true")
    List<Election> findElectionsWithPublishedResults();
    
    @Query("SELECT COUNT(e) FROM Election e WHERE e.status = :status")
    long countByStatus(@Param("status") ElectionStatus status);
    
    Optional<Election> findFirstByStatusOrderByStartDateAsc(ElectionStatus status);
}
