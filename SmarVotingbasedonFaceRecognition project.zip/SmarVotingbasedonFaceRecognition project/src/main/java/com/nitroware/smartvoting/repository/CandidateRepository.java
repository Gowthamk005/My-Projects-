package com.nitroware.smartvoting.repository;

import com.nitroware.smartvoting.model.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateRepository extends JpaRepository<Candidate, Long> {
    
    List<Candidate> findByElectionId(Long electionId);
    
    List<Candidate> findByElectionIdAndActive(Long electionId, boolean active);
    
    List<Candidate> findByPartyName(String partyName);
    
    @Query("SELECT c FROM Candidate c WHERE c.election.id = :electionId ORDER BY c.voteCount DESC")
    List<Candidate> findByElectionIdOrderByVoteCountDesc(@Param("electionId") Long electionId);
    
    @Query("SELECT c FROM Candidate c WHERE c.election.id = :electionId AND c.active = true ORDER BY c.name ASC")
    List<Candidate> findActiveCandidatesForElection(@Param("electionId") Long electionId);
    
    @Query("SELECT SUM(c.voteCount) FROM Candidate c WHERE c.election.id = :electionId")
    Long getTotalVotesForElection(@Param("electionId") Long electionId);
    
    List<Candidate> findByConstituency(String constituency);
}
