package com.nitroware.smartvoting.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "candidates")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Candidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String partyName;

    private String partySymbol;  // Path to party symbol image

    private String photoPath;  // Candidate photo

    @Column(columnDefinition = "TEXT")
    private String biography;

    private String qualification;

    private Integer age;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "election_id", nullable = false)
    private Election election;

    @Column(nullable = false)
    private int voteCount = 0;

    private String constituency;

    @Column(nullable = false)
    private boolean active = true;

    public void incrementVoteCount() {
        this.voteCount++;
    }
}
