package com.nitroware.smartvoting.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FaceVerificationRequest {
    private String faceImage;  // Base64 encoded image
    private Long voterId;
}
