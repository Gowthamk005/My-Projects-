package com.nitroware.smartvoting.controller;

import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.service.*;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class PageController {

    private final AuthService authService;
    private final VoterService voterService;
    private final ElectionService electionService;
    private final DashboardService dashboardService;
    private final CandidateService candidateService;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("activeElections", electionService.getActiveElections());
        model.addAttribute("upcomingElections", electionService.getUpcomingElections());
        return "home";
    }

    @GetMapping("/home")
    public String homePage(Model model) {
        return home(model);
    }

    @GetMapping("/login")
    public String loginPage(@RequestParam(required = false) String error,
                           @RequestParam(required = false) String logout,
                           Model model) {
        if (error != null) {
            model.addAttribute("error", "Invalid email or password");
        }
        if (logout != null) {
            model.addAttribute("message", "You have been logged out successfully");
        }
        return "login";
    }

    @PostMapping("/perform-login")
    public String performLogin(@Valid LoginRequest request, 
                              org.springframework.validation.BindingResult bindingResult,
                              HttpServletResponse response,
                              RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "Invalid input format");
            return "redirect:/login";
        }

        LoginResponse loginResponse = authService.login(request);
        
        if (loginResponse.getToken() != null) {
            // Set JWT cookie
            Cookie cookie = new Cookie("jwt", loginResponse.getToken());
            cookie.setHttpOnly(true);
            cookie.setPath("/");
            cookie.setMaxAge(86400); // 24 hours
            response.addCookie(cookie);
            
            return "redirect:/dashboard";
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid email or password");
            return "redirect:/login";
        }
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("registrationRequest", new VoterRegistrationRequest());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute VoterRegistrationRequest request,
                          org.springframework.validation.BindingResult bindingResult,
                          RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            String errors = bindingResult.getAllErrors().stream()
                .map(org.springframework.context.support.DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(java.util.stream.Collectors.joining(", "));
            redirectAttributes.addFlashAttribute("error", errors);
            return "redirect:/register";
        }

        ApiResponse<VoterResponse> response = authService.registerVoter(request);
        
        if (response.isSuccess()) {
            redirectAttributes.addFlashAttribute("success", 
                "Registration successful! Please login and register your face.");
            return "redirect:/login";
        } else {
            redirectAttributes.addFlashAttribute("error", response.getMessage());
            return "redirect:/register";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User user = authService.getCurrentUser();
        if (user == null) {
            return "redirect:/login";
        }

        model.addAttribute("user", user);

        if (user.getRole() == Role.ADMIN) {
            model.addAttribute("stats", dashboardService.getDashboardStats());
            model.addAttribute("pendingVoters", voterService.getPendingVoters());
            return "admin/dashboard";
        } else if (user.getRole() == Role.VOTER) {
            Voter voter = voterService.getVoterByUserId(user.getId());
            model.addAttribute("voter", voter);
            model.addAttribute("activeElections", electionService.getActiveElections());
            return "voter/dashboard";
        }

        return "redirect:/";
    }

    // Voter Pages
    @GetMapping("/voter/face-registration")
    public String faceRegistration(Model model) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) {
            return "redirect:/login";
        }
        model.addAttribute("voter", voter);
        return "voter/face-registration";
    }

    @GetMapping("/voter/vote/{electionId}")
    public String votePage(@PathVariable Long electionId, Model model) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) {
            return "redirect:/login";
        }

        if (voter.getStatus() != VoterStatus.APPROVED) {
            model.addAttribute("error", "Your account is not approved for voting");
            return "voter/dashboard";
        }

        ElectionResponse election = electionService.getElectionById(electionId);
        List<CandidateResponse> candidates = candidateService.getCandidatesByElection(electionId);

        model.addAttribute("voter", voter);
        model.addAttribute("election", election);
        model.addAttribute("candidates", candidates);
        return "voter/vote";
    }

    @GetMapping("/results/{electionId}")
    public String resultsPage(@PathVariable Long electionId, Model model) {
        ElectionResponse election = electionService.getElectionById(electionId);
        List<CandidateResponse> results = electionService.getElectionResults(electionId);
        
        model.addAttribute("election", election);
        model.addAttribute("results", results);
        model.addAttribute("result", results);
        return "results";
    }
    
    @GetMapping("/voter/history")
    public String voterHistoryPage(Model model) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) return "redirect:/login";
        
        model.addAttribute("voter", voter);
        model.addAttribute("votes", voterService.getVotingHistory(voter.getId()));
        return "voter/history";
    }

    @GetMapping("/voter/profile")
    public String voterProfilePage(Model model) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) return "redirect:/login";
        
        model.addAttribute("voter", voter);
        model.addAttribute("user", voter.getUser());
        return "voter/profile";
    }

    // Admin Pages
    @GetMapping("/admin/voters")
    public String adminVotersPage(Model model) {
        User user = authService.getCurrentUser();
        if (user == null || user.getRole() != Role.ADMIN) {
            return "redirect:/login";
        }
        
        model.addAttribute("voters", voterService.getAllVoters());
        return "admin/voters";
    }

    @GetMapping("/admin/voters/{id}")
    public String adminVoterDetailPage(@PathVariable Long id, Model model) {
        User user = authService.getCurrentUser();
        if (user == null || user.getRole() != Role.ADMIN) {
            return "redirect:/login";
        }
        
        Voter voter = voterService.getVoterById(id);
        model.addAttribute("voter", voter);
        return "admin/voter-detail";
    }

    @GetMapping("/admin/elections")
    public String adminElectionsPage(Model model) {
        User user = authService.getCurrentUser();
        if (user == null || user.getRole() != Role.ADMIN) {
            return "redirect:/login";
        }
        
        model.addAttribute("elections", electionService.getAllElections());
        return "admin/elections";
    }

    @GetMapping("/admin/elections/new")
    public String adminNewElectionPage(Model model) {
        User user = authService.getCurrentUser();
        if (user == null || user.getRole() != Role.ADMIN) {
            return "redirect:/login";
        }
        
        model.addAttribute("electionRequest", new ElectionRequest());
        return "admin/election-form";
    }

    @GetMapping("/admin/elections/{id}")
    public String adminElectionDetailPage(@PathVariable Long id, Model model) {
        User user = authService.getCurrentUser();
        if (user == null || user.getRole() != Role.ADMIN) {
            return "redirect:/login";
        }
        
        ElectionResponse election = electionService.getElectionById(id);
        List<CandidateResponse> candidates = candidateService.getCandidatesByElection(id);
        
        model.addAttribute("election", election);
        model.addAttribute("candidates", candidates != null ? candidates : List.of());
        return "admin/election-detail";
    }

    @GetMapping("/admin/candidates")
    public String adminCandidatesPage(Model model) {
        User user = authService.getCurrentUser();
        if (user == null || user.getRole() != Role.ADMIN) {
            return "redirect:/login";
        }
        
        model.addAttribute("candidates", candidateService.getAllCandidates());
        model.addAttribute("elections", electionService.getAllElections());
        return "admin/candidates";
    }

    @GetMapping("/admin/blockchain")
    public String adminBlockchainPage(Model model) {
        User user = authService.getCurrentUser();
        if (user == null || user.getRole() != Role.ADMIN) {
            return "redirect:/login";
        }
        
        return "admin/blockchain";
    }
}
