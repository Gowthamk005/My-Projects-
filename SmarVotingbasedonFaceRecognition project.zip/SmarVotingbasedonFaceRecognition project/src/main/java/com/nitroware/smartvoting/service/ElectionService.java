package com.nitroware.smartvoting.service;

import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ElectionService {

    private final ElectionRepository electionRepository;
    private final CandidateRepository candidateRepository;
    private final VoteRepository voteRepository;

    public List<ElectionResponse> getAllElections() {
        return electionRepository.findAll().stream()
                .map(this::mapToElectionResponse)
                .collect(Collectors.toList());
    }

    public ElectionResponse getElectionById(Long id) {
        Election election = electionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Election not found"));
        return mapToElectionResponse(election);
    }

    public List<ElectionResponse> getActiveElections() {
        return electionRepository.findActiveElections(LocalDateTime.now()).stream()
                .map(this::mapToElectionResponse)
                .collect(Collectors.toList());
    }

    public List<ElectionResponse> getUpcomingElections() {
        return electionRepository.findUpcomingElections(LocalDateTime.now()).stream()
                .map(this::mapToElectionResponse)
                .collect(Collectors.toList());
    }

    public List<ElectionResponse> getCompletedElections() {
        return electionRepository.findCompletedElections(LocalDateTime.now()).stream()
                .map(this::mapToElectionResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public ApiResponse<ElectionResponse> createElection(ElectionRequest request) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

            Election election = Election.builder()
                    .title(request.getTitle())
                    .description(request.getDescription())
                    .startDate(LocalDateTime.parse(request.getStartDate(), formatter))
                    .endDate(LocalDateTime.parse(request.getEndDate(), formatter))
                    .type(ElectionType.valueOf(request.getType().toUpperCase()))
                    .constituency(request.getConstituency())
                    .status(ElectionStatus.UPCOMING)
                    .resultsPublished(false)
                    .build();

            election = electionRepository.save(election);
            return ApiResponse.success(mapToElectionResponse(election), "Election created successfully");

        } catch (Exception e) {
            log.error("Error creating election: ", e);
            return ApiResponse.error("Failed to create election: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<ElectionResponse> updateElection(Long id, ElectionRequest request) {
        try {
            Election election = electionRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Election not found"));

            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

            election.setTitle(request.getTitle());
            election.setDescription(request.getDescription());
            election.setStartDate(LocalDateTime.parse(request.getStartDate(), formatter));
            election.setEndDate(LocalDateTime.parse(request.getEndDate(), formatter));
            election.setType(ElectionType.valueOf(request.getType().toUpperCase()));
            election.setConstituency(request.getConstituency());

            election = electionRepository.save(election);
            return ApiResponse.success(mapToElectionResponse(election), "Election updated successfully");

        } catch (Exception e) {
            log.error("Error updating election: ", e);
            return ApiResponse.error("Failed to update election: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<Void> deleteElection(Long id) {
        try {
            Election election = electionRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Election not found"));

            if (election.getStatus() == ElectionStatus.ACTIVE) {
                return ApiResponse.error("Cannot delete an active election");
            }

            electionRepository.delete(election);
            return ApiResponse.success(null, "Election deleted successfully");

        } catch (Exception e) {
            log.error("Error deleting election: ", e);
            return ApiResponse.error("Failed to delete election: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<ElectionResponse> startElection(Long id) {
        Election election = electionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Election not found"));

        if (election.getCandidates().isEmpty()) {
            return ApiResponse.error("Cannot start election without candidates");
        }

        election.setStatus(ElectionStatus.ACTIVE);
        election = electionRepository.save(election);
        return ApiResponse.success(mapToElectionResponse(election), "Election started successfully");
    }

    @Transactional
    public ApiResponse<ElectionResponse> endElection(Long id) {
        Election election = electionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Election not found"));

        election.setStatus(ElectionStatus.COMPLETED);
        election = electionRepository.save(election);
        return ApiResponse.success(mapToElectionResponse(election), "Election ended successfully");
    }

    @Transactional
    public ApiResponse<ElectionResponse> publishResults(Long id) {
        Election election = electionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Election not found"));

        if (election.getStatus() != ElectionStatus.COMPLETED) {
            return ApiResponse.error("Can only publish results for completed elections");
        }

        election.setResultsPublished(true);
        election = electionRepository.save(election);
        return ApiResponse.success(mapToElectionResponse(election), "Results published successfully");
    }

    public List<CandidateResponse> getElectionResults(Long electionId) {
        List<Candidate> candidates = candidateRepository.findByElectionIdOrderByVoteCountDesc(electionId);
        Long totalVotes = candidateRepository.getTotalVotesForElection(electionId);
        
        return candidates.stream()
                .map(c -> mapToCandidateResponse(c, totalVotes != null ? totalVotes : 0))
                .collect(Collectors.toList());
    }

    private ElectionResponse mapToElectionResponse(Election election) {
        return ElectionResponse.builder()
                .id(election.getId())
                .title(election.getTitle())
                .description(election.getDescription())
                .startDate(election.getStartDate())
                .endDate(election.getEndDate())
                .status(election.getStatus())
                .type(election.getType())
                .constituency(election.getConstituency())
                .totalVotes(election.getTotalVotes())
                .candidateCount(election.getCandidates().size())
                .resultsPublished(election.isResultsPublished())
                .candidates(election.getCandidates().stream()
                        .map(c -> mapToCandidateResponse(c, election.getTotalVotes()))
                        .collect(Collectors.toList()))
                .build();
    }

    private CandidateResponse mapToCandidateResponse(Candidate candidate, long totalVotes) {
        double percentage = totalVotes > 0 ? (double) candidate.getVoteCount() / totalVotes * 100 : 0;
        
        return CandidateResponse.builder()
                .id(candidate.getId())
                .name(candidate.getName())
                .partyName(candidate.getPartyName())
                .partySymbol(candidate.getPartySymbol())
                .photoPath(candidate.getPhotoPath())
                .biography(candidate.getBiography())
                .qualification(candidate.getQualification())
                .age(candidate.getAge())
                .voteCount(candidate.getVoteCount())
                .votePercentage(percentage)
                .constituency(candidate.getConstituency())
                .electionId(candidate.getElection().getId())
                .electionTitle(candidate.getElection().getTitle())
                .build();
    }
}
