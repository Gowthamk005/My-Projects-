package com.nitroware.smartvoting.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "voters")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Voter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    @Column(unique = true, nullable = false)
    private String voterId;  // Unique voter ID card number

    @Column(unique = true, nullable = false)
    private String aadhaarNumber;  // National ID

    private LocalDate dateOfBirth;

    private String address;

    private String city;

    private String state;

    private String pincode;

    @Column(nullable = false)
    private String gender;

    // Face recognition data
    @Column(columnDefinition = "TEXT")
    private String faceEncodingPath;  // Path to stored face encoding

    @Column(columnDefinition = "TEXT")
    private String faceImagePath;  // Path to face image

    @Column(nullable = false)
    private boolean faceRegistered = false;

    @Column(nullable = false)
    private boolean verified = false;  // Admin verified

    @Column(nullable = false)
    private boolean hasVoted = false;  // For current active election

    @Enumerated(EnumType.STRING)
    private VoterStatus status = VoterStatus.PENDING;

    private String rejectionReason;
}
