package com.nitroware.smartvoting.controller;

import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.Voter;
import com.nitroware.smartvoting.service.AuthService;
import com.nitroware.smartvoting.service.VoterService;
import com.nitroware.smartvoting.service.VotingService;
import com.nitroware.smartvoting.service.ElectionService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/voter")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('VOTER', 'ADMIN')")
public class VoterController {

    private final VoterService voterService;
    private final VotingService votingService;
    private final ElectionService electionService;
    private final AuthService authService;

    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<VoterResponse>> getProfile() {
        Voter voter = authService.getCurrentVoter();
        if (voter != null) {
            return ResponseEntity.ok(ApiResponse.success(voterService.mapToVoterResponse(voter)));
        }
        return ResponseEntity.badRequest().body(ApiResponse.error("Voter not found"));
    }

    @PostMapping("/register-face")
    public ResponseEntity<ApiResponse<VoterResponse>> registerFace(
            @RequestParam("faceImage") MultipartFile faceImage) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Voter not found"));
        }
        return ResponseEntity.ok(voterService.registerFace(voter.getId(), faceImage));
    }

    @PostMapping("/register-face-base64")
    public ResponseEntity<ApiResponse<VoterResponse>> registerFaceBase64(
            @RequestBody Map<String, String> payload) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Voter not found"));
        }
        String faceImage = payload.get("faceImage");
        return ResponseEntity.ok(voterService.registerFaceBase64(voter.getId(), faceImage));
    }

    @PostMapping("/verify-face")
    public ResponseEntity<FaceVerificationResponse> verifyFace(
            @RequestBody Map<String, String> payload) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) {
            return ResponseEntity.badRequest().body(
                    FaceVerificationResponse.builder().verified(false).message("Voter not found").build());
        }
        String faceImage = payload.get("faceImage");
        return ResponseEntity.ok(voterService.verifyFace(voter.getId(), faceImage));
    }

    @GetMapping("/elections/active")
    public ResponseEntity<List<ElectionResponse>> getActiveElections() {
        return ResponseEntity.ok(electionService.getActiveElections());
    }

    @GetMapping("/elections/{id}")
    public ResponseEntity<ElectionResponse> getElection(@PathVariable Long id) {
        return ResponseEntity.ok(electionService.getElectionById(id));
    }

    @PostMapping("/vote")
    public ResponseEntity<VoteResponse> castVote(
            @RequestBody VoteRequest request,
            HttpServletRequest httpRequest) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) {
            return ResponseEntity.badRequest().body(
                    VoteResponse.builder().success(false).message("Voter not found").build());
        }
        return ResponseEntity.ok(votingService.castVote(request, voter.getId(), httpRequest));
    }

    @GetMapping("/has-voted/{electionId}")
    public ResponseEntity<Map<String, Boolean>> hasVoted(@PathVariable Long electionId) {
        Voter voter = authService.getCurrentVoter();
        if (voter == null) {
            return ResponseEntity.ok(Map.of("hasVoted", false));
        }
        boolean hasVoted = votingService.hasVoted(voter.getId(), electionId);
        return ResponseEntity.ok(Map.of("hasVoted", hasVoted));
    }

    @GetMapping("/results/{electionId}")
    public ResponseEntity<List<CandidateResponse>> getResults(@PathVariable Long electionId) {
        return ResponseEntity.ok(electionService.getElectionResults(electionId));
    }
}
