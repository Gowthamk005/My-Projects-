package com.nitroware.smartvoting.model;

public enum VerificationType {
    REGISTRATION,  // Face registration during voter signup
    LOGIN,         // Face verification during login
    VOTING         // Face verification before casting vote
}
