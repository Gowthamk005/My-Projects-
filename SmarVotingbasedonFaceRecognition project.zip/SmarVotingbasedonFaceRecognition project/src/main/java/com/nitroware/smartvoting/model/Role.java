package com.nitroware.smartvoting.model;

public enum Role {
    ADMIN,
    VOTER,
    ELECTION_OFFICER
}
