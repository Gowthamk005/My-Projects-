package com.nitroware.smartvoting.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.time.LocalDateTime;

/**
 * Blockchain Transaction DTO
 * Represents a transaction on the blockchain (simulated or real Ganache)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BlockchainTransaction {
    private String transactionHash;
    private Long blockNumber;
    private String blockHash;
    private LocalDateTime timestamp;
    private String from;
    private String to;
    private String type; // FACE_REGISTRATION, VOTE_CAST
    private String status; // PENDING, CONFIRMED, FAILED
    private String voterId;
    private Long electionId;
    private Long candidateId;
    private String dataHash;
    private BigInteger gasUsed;
    private String contractAddress;
    
    public String getFormattedTimestamp() {
        if (timestamp != null) {
            return timestamp.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }
        return "";
    }
    
    public String getShortHash() {
        if (transactionHash != null && transactionHash.length() > 16) {
            return transactionHash.substring(0, 10) + "..." + transactionHash.substring(transactionHash.length() - 6);
        }
        return transactionHash;
    }
}
