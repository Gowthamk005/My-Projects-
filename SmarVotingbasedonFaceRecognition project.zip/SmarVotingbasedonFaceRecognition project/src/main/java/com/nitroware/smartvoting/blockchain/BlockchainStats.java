package com.nitroware.smartvoting.blockchain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Blockchain statistics DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BlockchainStats {
    private boolean connected;
    private String networkUrl;
    private String walletAddress;
    private long currentBlockNumber;
    private long totalTransactions;
    private long voteTransactions;
    private long faceRegistrations;
    private boolean simulationMode;
    private String contractAddress;
    private String networkName;
}
