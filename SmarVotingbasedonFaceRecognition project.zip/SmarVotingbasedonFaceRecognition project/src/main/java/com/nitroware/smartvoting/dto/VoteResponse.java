package com.nitroware.smartvoting.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoteResponse {
    private boolean success;
    private String message;
    private String voteHash;
    private String electionTitle;
    private String candidateName;
    
    // Blockchain details
    private String blockchainTxHash;
    private Long blockNumber;
}
