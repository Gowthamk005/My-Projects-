package com.nitroware.smartvoting.blockchain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

import com.nitroware.smartvoting.dto.BlockchainTransaction;

/**
 * Simulated block for local blockchain when Ganache is not available
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SimulatedBlock {
    private Long blockNumber;
    private LocalDateTime timestamp;
    private String previousHash;
    private String hash;
    private List<BlockchainTransaction> transactions;
    private Long nonce;
    private String miner;
    
    public int getTransactionCount() {
        return transactions != null ? transactions.size() : 0;
    }
}
