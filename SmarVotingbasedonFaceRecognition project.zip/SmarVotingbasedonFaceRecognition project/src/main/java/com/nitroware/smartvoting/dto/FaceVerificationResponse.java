package com.nitroware.smartvoting.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FaceVerificationResponse {
    private boolean verified;
    private double confidence;
    private String message;
    private String voterId;
}
