package com.nitroware.smartvoting.service;

import com.nitroware.smartvoting.blockchain.BlockchainService;
import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.repository.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class VotingService {

    private final VoteRepository voteRepository;
    private final VoterRepository voterRepository;
    private final CandidateRepository candidateRepository;
    private final ElectionRepository electionRepository;
    private final VoterService voterService;
    private final BlockchainService blockchainService;

    @Transactional
    public VoteResponse castVote(VoteRequest request, Long voterId, HttpServletRequest httpRequest) {
        try {
            // Get voter
            Voter voter = voterRepository.findById(voterId)
                    .orElseThrow(() -> new RuntimeException("Voter not found"));

            // Verify voter is approved
            if (voter.getStatus() != VoterStatus.APPROVED) {
                return VoteResponse.builder()
                        .success(false)
                        .message("Your account is not approved for voting")
                        .build();
            }

            // Verify face is registered
            if (!voter.isFaceRegistered()) {
                return VoteResponse.builder()
                        .success(false)
                        .message("Face not registered. Please register your face first.")
                        .build();
            }

            // Get election
            Election election = electionRepository.findById(request.getElectionId())
                    .orElseThrow(() -> new RuntimeException("Election not found"));

            // Check if election is active
            if (!election.isActive()) {
                return VoteResponse.builder()
                        .success(false)
                        .message("This election is not currently active")
                        .build();
            }

            // Check if already voted in this election
            if (voteRepository.existsByVoterIdAndElectionId(voterId, request.getElectionId())) {
                return VoteResponse.builder()
                        .success(false)
                        .message("You have already voted in this election")
                        .build();
            }

            // Verify face before voting
            FaceVerificationResponse faceResponse = voterService.verifyFace(voterId, request.getFaceImage());
            
            if (!faceResponse.isVerified()) {
                return VoteResponse.builder()
                        .success(false)
                        .message("Face verification failed: " + faceResponse.getMessage())
                        .build();
            }

            // Get candidate
            Candidate candidate = candidateRepository.findById(request.getCandidateId())
                    .orElseThrow(() -> new RuntimeException("Candidate not found"));

            // Verify candidate belongs to this election
            if (!candidate.getElection().getId().equals(request.getElectionId())) {
                return VoteResponse.builder()
                        .success(false)
                        .message("Invalid candidate for this election")
                        .build();
            }

            // Generate vote hash for verification
            String voteHash = generateVoteHash(voter.getVoterId(), election.getId(), candidate.getId());

            // Record vote on blockchain
            BlockchainTransaction blockchainTx = null;
            String blockchainTxHash = null;
            if (blockchainService.isEnabled()) {
                blockchainTx = blockchainService.recordVote(
                    voter.getVoterId(), 
                    election.getId(), 
                    candidate.getId(), 
                    voteHash
                );
                blockchainTxHash = blockchainTx.getTransactionHash();
                log.info("Vote recorded on blockchain: TxHash={}, Block={}", 
                    blockchainTxHash, blockchainTx.getBlockNumber());
            }

            // Create vote record
            Vote vote = Vote.builder()
                    .voter(voter)
                    .election(election)
                    .candidate(candidate)
                    .votedAt(LocalDateTime.now())
                    .voteHash(voteHash)
                    .blockchainTxHash(blockchainTxHash)
                    .ipAddress(getClientIp(httpRequest))
                    .deviceInfo(httpRequest.getHeader("User-Agent"))
                    .faceMatchConfidence(faceResponse.getConfidence())
                    .build();

            voteRepository.save(vote);

            // Increment candidate vote count
            candidate.incrementVoteCount();
            candidateRepository.save(candidate);

            // Mark voter as voted
            voter.setHasVoted(true);
            voterRepository.save(voter);

            log.info("Vote cast successfully: Voter={}, Election={}, Candidate={}, BlockchainTx={}", 
                    voter.getVoterId(), election.getTitle(), candidate.getName(), blockchainTxHash);

            return VoteResponse.builder()
                    .success(true)
                    .message("Your vote has been recorded successfully on the blockchain!")
                    .voteHash(voteHash)
                    .blockchainTxHash(blockchainTxHash)
                    .blockNumber(blockchainTx != null ? blockchainTx.getBlockNumber() : null)
                    .electionTitle(election.getTitle())
                    .candidateName(candidate.getName())
                    .build();

        } catch (Exception e) {
            log.error("Error casting vote: ", e);
            return VoteResponse.builder()
                    .success(false)
                    .message("Failed to cast vote: " + e.getMessage())
                    .build();
        }
    }

    public boolean hasVoted(Long voterId, Long electionId) {
        return voteRepository.existsByVoterIdAndElectionId(voterId, electionId);
    }

    public long getVoteCount(Long electionId) {
        return voteRepository.countVotesByElection(electionId);
    }

    public long getCandidateVoteCount(Long candidateId) {
        return voteRepository.countVotesByCandidate(candidateId);
    }

    private String generateVoteHash(String voterId, Long electionId, Long candidateId) {
        try {
            String data = voterId + "-" + electionId + "-" + candidateId + "-" + 
                         UUID.randomUUID() + "-" + System.currentTimeMillis();
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes());
            return Base64.getEncoder().encodeToString(hash).substring(0, 16);
        } catch (NoSuchAlgorithmException e) {
            return UUID.randomUUID().toString().substring(0, 16);
        }
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty()) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }
}
