package com.nitroware.smartvoting.repository;

import com.nitroware.smartvoting.model.Vote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface VoteRepository extends JpaRepository<Vote, Long> {
    
    boolean existsByVoterIdAndElectionId(Long voterId, Long electionId);
    
    List<Vote> findByVoterId(Long voterId);
    
    Optional<Vote> findByVoterIdAndElectionId(Long voterId, Long electionId);
    
    List<Vote> findByElectionId(Long electionId);
    
    List<Vote> findByCandidateId(Long candidateId);
    
    @Query("SELECT COUNT(v) FROM Vote v WHERE v.election.id = :electionId")
    long countVotesByElection(@Param("electionId") Long electionId);
    
    @Query("SELECT COUNT(v) FROM Vote v WHERE v.candidate.id = :candidateId")
    long countVotesByCandidate(@Param("candidateId") Long candidateId);
    
    @Query("SELECT v FROM Vote v WHERE v.votedAt BETWEEN :start AND :end")
    List<Vote> findVotesBetween(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
    
    @Query("SELECT COUNT(v) FROM Vote v WHERE v.election.id = :electionId AND v.votedAt BETWEEN :start AND :end")
    long countVotesInPeriod(@Param("electionId") Long electionId, 
                            @Param("start") LocalDateTime start, 
                            @Param("end") LocalDateTime end);
}
