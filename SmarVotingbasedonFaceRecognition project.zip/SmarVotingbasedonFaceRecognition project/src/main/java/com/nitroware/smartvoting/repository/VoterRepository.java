package com.nitroware.smartvoting.repository;

import com.nitroware.smartvoting.model.Voter;
import com.nitroware.smartvoting.model.VoterStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VoterRepository extends JpaRepository<Voter, Long> {
    
    Optional<Voter> findByVoterId(String voterId);
    
    Optional<Voter> findByAadhaarNumber(String aadhaarNumber);
    
    Optional<Voter> findByUserId(Long userId);
    
    Optional<Voter> findByUserEmail(String email);
    
    boolean existsByVoterId(String voterId);
    
    boolean existsByAadhaarNumber(String aadhaarNumber);
    
    List<Voter> findByStatus(VoterStatus status);
    
    List<Voter> findByVerified(boolean verified);
    
    List<Voter> findByFaceRegistered(boolean faceRegistered);
    
    @Query("SELECT v FROM Voter v WHERE v.status = :status AND v.faceRegistered = true")
    List<Voter> findApprovedWithFace(@Param("status") VoterStatus status);
    
    @Query("SELECT COUNT(v) FROM Voter v WHERE v.status = :status")
    long countByStatus(@Param("status") VoterStatus status);
    
    @Query("SELECT COUNT(v) FROM Voter v WHERE v.hasVoted = true")
    long countVotersWhoVoted();
    
    List<Voter> findByCity(String city);
    
    List<Voter> findByState(String state);
}
