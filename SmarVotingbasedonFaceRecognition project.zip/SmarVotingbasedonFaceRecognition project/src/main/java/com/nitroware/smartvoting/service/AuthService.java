package com.nitroware.smartvoting.service;

import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.repository.*;
import com.nitroware.smartvoting.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final VoterRepository voterRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final AuthenticationManager authenticationManager;

    @Transactional
    public ApiResponse<VoterResponse> registerVoter(VoterRegistrationRequest request) {
        try {
            // Check if email already exists
            if (userRepository.existsByEmail(request.getEmail())) {
                return ApiResponse.error("Email already registered");
            }

            // Check if voter ID already exists
            if (voterRepository.existsByVoterId(request.getVoterId())) {
                return ApiResponse.error("Voter ID already registered");
            }

            // Check if Aadhaar already exists
            if (voterRepository.existsByAadhaarNumber(request.getAadhaarNumber())) {
                return ApiResponse.error("Aadhaar number already registered");
            }

            // Create User
            User user = User.builder()
                    .email(request.getEmail())
                    .password(passwordEncoder.encode(request.getPassword()))
                    .firstName(request.getFirstName())
                    .lastName(request.getLastName())
                    .phone(request.getPhone())
                    .role(Role.VOTER)
                    .enabled(true)
                    .accountNonLocked(true)
                    .build();

            user = userRepository.save(user);

            // Create Voter
            Voter voter = Voter.builder()
                    .user(user)
                    .voterId(request.getVoterId())
                    .aadhaarNumber(request.getAadhaarNumber())
                    .dateOfBirth(LocalDate.parse(request.getDateOfBirth(), DateTimeFormatter.ISO_DATE))
                    .gender(request.getGender())
                    .address(request.getAddress())
                    .city(request.getCity())
                    .state(request.getState())
                    .pincode(request.getPincode())
                    .status(VoterStatus.PENDING)
                    .verified(false)
                    .faceRegistered(false)
                    .hasVoted(false)
                    .build();

            voter = voterRepository.save(voter);

            VoterResponse response = mapToVoterResponse(voter);
            return ApiResponse.success(response, "Registration successful. Please register your face and wait for admin verification.");

        } catch (Exception e) {
            log.error("Error registering voter: ", e);
            return ApiResponse.error("Registration failed: " + e.getMessage());
        }
    }

    public LoginResponse login(LoginRequest request) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);

            User user = userRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            String token = jwtTokenProvider.generateToken(user.getEmail(), user.getRole().name());

            boolean faceRegistered = false;
            if (user.getRole() == Role.VOTER) {
                Voter voter = voterRepository.findByUserId(user.getId()).orElse(null);
                if (voter != null) {
                    faceRegistered = voter.isFaceRegistered();
                }
            }

            return LoginResponse.builder()
                    .token(token)
                    .email(user.getEmail())
                    .role(user.getRole().name())
                    .fullName(user.getFullName())
                    .userId(user.getId())
                    .faceRegistered(faceRegistered)
                    .message("Login successful")
                    .build();

        } catch (Exception e) {
            log.error("Login failed: ", e);
            return LoginResponse.builder()
                    .message("Invalid email or password")
                    .build();
        }
    }

    public User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            String email = authentication.getName();
            return userRepository.findByEmail(email).orElse(null);
        }
        return null;
    }

    public Voter getCurrentVoter() {
        User user = getCurrentUser();
        if (user != null && user.getRole() == Role.VOTER) {
            return voterRepository.findByUserId(user.getId()).orElse(null);
        }
        return null;
    }

    private VoterResponse mapToVoterResponse(Voter voter) {
        return VoterResponse.builder()
                .id(voter.getId())
                .email(voter.getUser().getEmail())
                .firstName(voter.getUser().getFirstName())
                .lastName(voter.getUser().getLastName())
                .fullName(voter.getUser().getFullName())
                .phone(voter.getUser().getPhone())
                .voterId(voter.getVoterId())
                .aadhaarNumber(voter.getAadhaarNumber())
                .dateOfBirth(voter.getDateOfBirth())
                .gender(voter.getGender())
                .address(voter.getAddress())
                .city(voter.getCity())
                .state(voter.getState())
                .pincode(voter.getPincode())
                .faceRegistered(voter.isFaceRegistered())
                .verified(voter.isVerified())
                .hasVoted(voter.isHasVoted())
                .status(voter.getStatus())
                .faceImagePath(voter.getFaceImagePath())
                .build();
    }
}
