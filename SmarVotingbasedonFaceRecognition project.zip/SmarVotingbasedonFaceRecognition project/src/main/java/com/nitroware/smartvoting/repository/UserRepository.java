package com.nitroware.smartvoting.repository;

import com.nitroware.smartvoting.model.User;
import com.nitroware.smartvoting.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    Optional<User> findByEmail(String email);
    
    boolean existsByEmail(String email);
    
    List<User> findByRole(Role role);
    
    List<User> findByEnabled(boolean enabled);
    
    Optional<User> findByEmailAndEnabled(String email, boolean enabled);
}
