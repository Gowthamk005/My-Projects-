package com.nitroware.smartvoting.blockchain;

import com.nitroware.smartvoting.dto.BlockchainTransaction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.methods.response.*;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.Transfer;
import org.web3j.utils.Convert;

import jakarta.annotation.PostConstruct;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * BlockchainService - Integrates with Ganache for simulated blockchain storage
 * Stores face registrations and votes on the blockchain
 */
@Service
@Slf4j
public class BlockchainService {

    @Value("${app.blockchain.ganache-url:http://127.0.0.1:7545}")
    private String ganacheUrl;

    @Value("${app.blockchain.private-key:0x4f3edf983ac636a65a842ce7c78d9aa706d3b113bce9c46f30d7d21715b23b1d}")
    private String privateKey;

    @Value("${app.blockchain.enabled:true}")
    private boolean blockchainEnabled;

    private Web3j web3j;
    private Credentials credentials;
    private boolean connected = false;

    // In-memory blockchain simulation when Ganache is not available
    private final Map<String, BlockchainTransaction> transactionStore = new ConcurrentHashMap<>();
    private final List<SimulatedBlock> blockchain = Collections.synchronizedList(new ArrayList<>());
    private long blockNumber = 0;

    @PostConstruct
    public void init() {
        if (!blockchainEnabled) {
            log.info("Blockchain integration disabled");
            return;
        }

        try {
            log.info("Connecting to Ganache blockchain at: {}", ganacheUrl);
            web3j = Web3j.build(new HttpService(ganacheUrl));
            
            // Test connection
            Web3ClientVersion clientVersion = web3j.web3ClientVersion().send();
            log.info("Connected to Ethereum client: {}", clientVersion.getWeb3ClientVersion());
            
            // Load credentials from private key
            credentials = Credentials.create(privateKey);
            log.info("Blockchain wallet address: {}", credentials.getAddress());
            
            // Get balance
            EthGetBalance balance = web3j.ethGetBalance(
                credentials.getAddress(), 
                DefaultBlockParameterName.LATEST
            ).send();
            log.info("Wallet balance: {} ETH", 
                Convert.fromWei(balance.getBalance().toString(), Convert.Unit.ETHER));
            
            connected = true;
            log.info("✓ Successfully connected to Ganache blockchain");
            
        } catch (Exception e) {
            log.warn("Could not connect to Ganache. Using simulated blockchain. Error: {}", e.getMessage());
            connected = false;
            initializeSimulatedBlockchain();
        }
    }

    private void initializeSimulatedBlockchain() {
        // Create genesis block
        SimulatedBlock genesisBlock = SimulatedBlock.builder()
            .blockNumber(0L)
            .timestamp(LocalDateTime.now())
            .previousHash("0x0000000000000000000000000000000000000000000000000000000000000000")
            .hash(generateHash("genesis"))
            .transactions(new ArrayList<>())
            .build();
        blockchain.add(genesisBlock);
        log.info("✓ Simulated blockchain initialized with genesis block");
    }

    /**
     * Record a face registration on the blockchain
     */
    public BlockchainTransaction recordFaceRegistration(String voterId, String faceHash, String imagePath) {
        String dataHash = generateHash(voterId + faceHash + imagePath + System.currentTimeMillis());
        
        BlockchainTransaction tx = BlockchainTransaction.builder()
            .transactionHash("0x" + dataHash.substring(0, 64))
            .blockNumber(getNextBlockNumber())
            .timestamp(LocalDateTime.now())
            .from(getWalletAddress())
            .to(getContractAddress())
            .type("FACE_REGISTRATION")
            .status("CONFIRMED")
            .voterId(voterId)
            .dataHash(faceHash)
            .gasUsed(BigInteger.valueOf(21000 + (long)(Math.random() * 5000)))
            .build();

        if (connected) {
            tx = recordOnGanache(tx);
        } else {
            tx = recordOnSimulatedBlockchain(tx);
        }

        transactionStore.put(tx.getTransactionHash(), tx);
        log.info("Face registration recorded on blockchain. TxHash: {}", tx.getTransactionHash());
        
        return tx;
    }

    /**
     * Record a vote on the blockchain
     */
    public BlockchainTransaction recordVote(String voterId, Long electionId, Long candidateId, String voteHash) {
        String dataHash = generateHash(voterId + electionId + candidateId + voteHash + System.currentTimeMillis());
        
        BlockchainTransaction tx = BlockchainTransaction.builder()
            .transactionHash("0x" + dataHash.substring(0, 64))
            .blockNumber(getNextBlockNumber())
            .timestamp(LocalDateTime.now())
            .from(getWalletAddress())
            .to(getContractAddress())
            .type("VOTE_CAST")
            .status("CONFIRMED")
            .voterId(voterId)
            .electionId(electionId)
            .candidateId(candidateId)
            .dataHash(voteHash)
            .gasUsed(BigInteger.valueOf(45000 + (long)(Math.random() * 10000)))
            .build();

        if (connected) {
            tx = recordOnGanache(tx);
        } else {
            tx = recordOnSimulatedBlockchain(tx);
        }

        transactionStore.put(tx.getTransactionHash(), tx);
        log.info("Vote recorded on blockchain. TxHash: {}, ElectionId: {}", tx.getTransactionHash(), electionId);
        
        return tx;
    }

    /**
     * Verify a transaction exists on the blockchain
     */
    public boolean verifyTransaction(String transactionHash) {
        if (connected) {
            try {
                EthTransaction ethTx = web3j.ethGetTransactionByHash(transactionHash).send();
                return ethTx.getTransaction().isPresent();
            } catch (Exception e) {
                log.error("Error verifying transaction: ", e);
            }
        }
        return transactionStore.containsKey(transactionHash);
    }

    /**
     * Get transaction details
     */
    public Optional<BlockchainTransaction> getTransaction(String transactionHash) {
        return Optional.ofNullable(transactionStore.get(transactionHash));
    }

    /**
     * Get all transactions for a voter
     */
    public List<BlockchainTransaction> getVoterTransactions(String voterId) {
        return transactionStore.values().stream()
            .filter(tx -> voterId.equals(tx.getVoterId()))
            .sorted((a, b) -> b.getTimestamp().compareTo(a.getTimestamp()))
            .toList();
    }

    /**
     * Get blockchain statistics
     */
    public BlockchainStats getBlockchainStats() {
        long totalTransactions = transactionStore.size();
        long voteTransactions = transactionStore.values().stream()
            .filter(tx -> "VOTE_CAST".equals(tx.getType()))
            .count();
        long faceRegistrations = transactionStore.values().stream()
            .filter(tx -> "FACE_REGISTRATION".equals(tx.getType()))
            .count();

        return BlockchainStats.builder()
            .connected(connected)
            .networkUrl(ganacheUrl)
            .walletAddress(getWalletAddress())
            .currentBlockNumber(blockNumber)
            .totalTransactions(totalTransactions)
            .voteTransactions(voteTransactions)
            .faceRegistrations(faceRegistrations)
            .simulationMode(!connected)
            .build();
    }

    /**
     * Get recent blockchain transactions 
     */
    public List<BlockchainTransaction> getRecentTransactions(int limit) {
        return transactionStore.values().stream()
            .sorted((a, b) -> b.getTimestamp().compareTo(a.getTimestamp()))
            .limit(limit)
            .toList();
    }

    // Private helper methods

    private BlockchainTransaction recordOnGanache(BlockchainTransaction tx) {
        try {
            // Send a small transaction to record on blockchain
            TransactionReceipt receipt = Transfer.sendFunds(
                web3j, 
                credentials, 
                credentials.getAddress(), // Send to self
                BigDecimal.valueOf(0.0001), 
                Convert.Unit.ETHER
            ).send();

            tx.setTransactionHash(receipt.getTransactionHash());
            tx.setBlockNumber(receipt.getBlockNumber().longValue());
            tx.setGasUsed(receipt.getGasUsed());
            tx.setStatus("CONFIRMED");
            
            log.info("Transaction confirmed on Ganache. Block: {}", receipt.getBlockNumber());
            
        } catch (Exception e) {
            log.error("Error recording on Ganache: ", e);
            tx.setStatus("FAILED");
        }
        return tx;
    }

    private BlockchainTransaction recordOnSimulatedBlockchain(BlockchainTransaction tx) {
        // Add to current block
        blockNumber++;
        
        SimulatedBlock newBlock = SimulatedBlock.builder()
            .blockNumber(blockNumber)
            .timestamp(LocalDateTime.now())
            .previousHash(blockchain.get(blockchain.size() - 1).getHash())
            .hash(generateHash("block" + blockNumber + tx.getTransactionHash()))
            .transactions(List.of(tx))
            .build();
        
        blockchain.add(newBlock);
        tx.setBlockNumber(blockNumber);
        tx.setBlockHash(newBlock.getHash());
        tx.setStatus("CONFIRMED");
        
        return tx;
    }

    private String generateHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return UUID.randomUUID().toString().replace("-", "") + 
                   UUID.randomUUID().toString().replace("-", "");
        }
    }

    private long getNextBlockNumber() {
        if (connected) {
            try {
                EthBlockNumber blockNum = web3j.ethBlockNumber().send();
                return blockNum.getBlockNumber().longValue() + 1;
            } catch (Exception e) {
                log.error("Error getting block number: ", e);
            }
        }
        return blockNumber + 1;
    }

    private String getWalletAddress() {
        if (credentials != null) {
            return credentials.getAddress();
        }
        return "0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1"; // Default Ganache address
    }

    private String getContractAddress() {
        return "0xVotingSmartContract000000000000000000001";
    }

    public boolean isConnected() {
        return connected;
    }

    public boolean isEnabled() {
        return blockchainEnabled;
    }
}
