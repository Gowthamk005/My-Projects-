package com.nitroware.smartvoting.service;

import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CandidateService {

    private final CandidateRepository candidateRepository;
    private final ElectionRepository electionRepository;

    @Value("${app.upload.candidate-images-dir}")
    private String candidateImagesDir;

    public List<CandidateResponse> getAllCandidates() {
        return candidateRepository.findAll().stream()
                .map(this::mapToCandidateResponse)
                .collect(Collectors.toList());
    }

    public CandidateResponse getCandidateById(Long id) {
        Candidate candidate = candidateRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Candidate not found"));
        return mapToCandidateResponse(candidate);
    }

    public List<CandidateResponse> getCandidatesByElection(Long electionId) {
        return candidateRepository.findActiveCandidatesForElection(electionId).stream()
                .map(this::mapToCandidateResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public ApiResponse<CandidateResponse> createCandidate(CandidateRequest request) {
        try {
            Election election = electionRepository.findById(request.getElectionId())
                    .orElseThrow(() -> new RuntimeException("Election not found"));

            if (election.getStatus() == ElectionStatus.ACTIVE || 
                election.getStatus() == ElectionStatus.COMPLETED) {
                return ApiResponse.error("Cannot add candidates to active or completed elections");
            }

            Candidate candidate = Candidate.builder()
                    .name(request.getName())
                    .partyName(request.getPartyName())
                    .partySymbol(request.getPartySymbol())
                    .biography(request.getBiography())
                    .qualification(request.getQualification())
                    .age(request.getAge())
                    .election(election)
                    .constituency(request.getConstituency())
                    .voteCount(0)
                    .active(true)
                    .build();

            candidate = candidateRepository.save(candidate);
            return ApiResponse.success(mapToCandidateResponse(candidate), "Candidate added successfully");

        } catch (Exception e) {
            log.error("Error creating candidate: ", e);
            return ApiResponse.error("Failed to add candidate: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<CandidateResponse> updateCandidate(Long id, CandidateRequest request) {
        try {
            Candidate candidate = candidateRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Candidate not found"));

            candidate.setName(request.getName());
            candidate.setPartyName(request.getPartyName());
            candidate.setPartySymbol(request.getPartySymbol());
            candidate.setBiography(request.getBiography());
            candidate.setQualification(request.getQualification());
            candidate.setAge(request.getAge());
            candidate.setConstituency(request.getConstituency());

            candidate = candidateRepository.save(candidate);
            return ApiResponse.success(mapToCandidateResponse(candidate), "Candidate updated successfully");

        } catch (Exception e) {
            log.error("Error updating candidate: ", e);
            return ApiResponse.error("Failed to update candidate: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<CandidateResponse> uploadCandidatePhoto(Long id, MultipartFile photo) {
        try {
            Candidate candidate = candidateRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Candidate not found"));

            String fileName = "candidate_" + id + "_" + UUID.randomUUID() + ".jpg";
            Path uploadPath = Paths.get(candidateImagesDir);
            
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(fileName);
            Files.copy(photo.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            candidate.setPhotoPath(filePath.toString());
            candidate = candidateRepository.save(candidate);

            return ApiResponse.success(mapToCandidateResponse(candidate), "Photo uploaded successfully");

        } catch (Exception e) {
            log.error("Error uploading candidate photo: ", e);
            return ApiResponse.error("Failed to upload photo: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<Void> deleteCandidate(Long id) {
        try {
            Candidate candidate = candidateRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Candidate not found"));

            Election election = candidate.getElection();
            if (election.getStatus() == ElectionStatus.ACTIVE) {
                return ApiResponse.error("Cannot delete candidates from active elections");
            }

            candidateRepository.delete(candidate);
            return ApiResponse.success(null, "Candidate deleted successfully");

        } catch (Exception e) {
            log.error("Error deleting candidate: ", e);
            return ApiResponse.error("Failed to delete candidate: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<Void> deactivateCandidate(Long id) {
        Candidate candidate = candidateRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Candidate not found"));

        candidate.setActive(false);
        candidateRepository.save(candidate);
        return ApiResponse.success(null, "Candidate deactivated successfully");
    }

    private CandidateResponse mapToCandidateResponse(Candidate candidate) {
        Long totalVotes = candidateRepository.getTotalVotesForElection(candidate.getElection().getId());
        double percentage = (totalVotes != null && totalVotes > 0) 
                ? (double) candidate.getVoteCount() / totalVotes * 100 
                : 0;

        return CandidateResponse.builder()
                .id(candidate.getId())
                .name(candidate.getName())
                .partyName(candidate.getPartyName())
                .partySymbol(candidate.getPartySymbol())
                .photoPath(candidate.getPhotoPath())
                .biography(candidate.getBiography())
                .qualification(candidate.getQualification())
                .age(candidate.getAge())
                .voteCount(candidate.getVoteCount())
                .votePercentage(percentage)
                .constituency(candidate.getConstituency())
                .electionId(candidate.getElection().getId())
                .electionTitle(candidate.getElection().getTitle())
                .build();
    }
}
