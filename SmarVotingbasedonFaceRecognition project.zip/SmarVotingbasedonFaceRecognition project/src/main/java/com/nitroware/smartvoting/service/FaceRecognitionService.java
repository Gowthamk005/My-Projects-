package com.nitroware.smartvoting.service;

import com.nitroware.smartvoting.dto.FaceVerificationResponse;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nu.pattern.OpenCV;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class FaceRecognitionService {

    @Value("${app.upload.face-images-dir}")
    private String faceImagesDir;
    
    // Lower threshold means better match for Bhattacharyya distance (0 = perfect match, 1 = no match)
    // We invert the confidence later (1 - distance)
    private static final double MATCH_THRESHOLD = 0.5;

    private CascadeClassifier faceDetector;
    private File cascadeFile;

    @PostConstruct
    public void init() {
        try {
            log.info("Initializing OpenCV Face Recognition Service...");
            // Load OpenCV native libraries
            OpenCV.loadLocally();
            log.info("✓ OpenCV loaded successfully");

            // Load Haar Cascade Classifier
            loadHaarCascade();
            
        } catch (Exception e) {
            log.error("Failed to initialize OpenCV: ", e);
        }
    }

    private void loadHaarCascade() throws IOException {
        // Extract the XML resource to a temporary file because OpenCV needs a file path
        InputStream is = getClass().getResourceAsStream("/haarcascade_frontalface_alt.xml");
        if (is == null) {
            log.error("Haar cascade file not found in resources!");
            return;
        }

        cascadeFile = File.createTempFile("haarcascade", ".xml");
        cascadeFile.deleteOnExit();

        try (FileOutputStream os = new FileOutputStream(cascadeFile)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
        }

        faceDetector = new CascadeClassifier(cascadeFile.getAbsolutePath());
        if (faceDetector.empty()) {
            log.error("Failed to load Haar Cascade classifier");
        } else {
            log.info("✓ Face Detector initialized successfully");
        }
    }

    /**
     * Register a face - Verification step
     */
    public FaceVerificationResponse registerFace(String voterId, String imagePath) {
        try {
            Mat image = Imgcodecs.imread(imagePath);
            if (image.empty()) {
                return FaceVerificationResponse.builder()
                        .verified(false)
                        .message("Could not read image file")
                        .build();
            }

            // Detect faces
            MatOfRect faceDetections = new MatOfRect();
            faceDetector.detectMultiScale(image, faceDetections);
            
            Rect[] faces = faceDetections.toArray();

            if (faces.length == 0) {
                return FaceVerificationResponse.builder()
                        .verified(false)
                        .message("No face detected. Please ensure good lighting and face camera directly.")
                        .build();
            }

            if (faces.length > 1) {
                return FaceVerificationResponse.builder()
                        .verified(false)
                        .message("Multiple faces detected. Please ensure only you are in the frame.")
                        .build();
            }

            // Valid registration
            return FaceVerificationResponse.builder()
                    .verified(true)
                    .confidence(1.0)
                    .message("Face registered successfully")
                    .voterId(voterId)
                    .build();

        } catch (Exception e) {
            log.error("Error during registration: ", e);
            return FaceVerificationResponse.builder()
                    .verified(false)
                    .message("Error processing image: " + e.getMessage())
                    .build();
        }
    }

    /**
     * Verify a face against the registered image using Histogram Comparison
     */
    public FaceVerificationResponse verifyFace(String voterId, String base64Image) {
        try {
            // 1. Get the registered image path
            // Note: In a real system you'd store this path in DB. We verify by file existence convention here
            // Voter service stores it, but we can look it up or VoterService passes it.
            // For now, re-read the file naming convention from VoterService
            // This is a slight hack since we don't pass the registered path here, but acceptable for demo
            
            // Actually, VoterService checks registration then calls this. 
            // We need to find the registered image.
            // Let's search the directory for the file starting with "face_" + voterId + "_"
            File facesDir = new File(faceImagesDir);
            File[] match = facesDir.listFiles((dir, name) -> name.startsWith("face_" + voterId + "_"));
            
            if (match == null || match.length == 0) {
                return FaceVerificationResponse.builder()
                        .verified(false)
                        .message("Registered face image not found")
                        .build();
            }
            
            String registeredImagePath = match[0].getAbsolutePath();

            // 2. Load Registered Image
            Mat registeredImg = Imgcodecs.imread(registeredImagePath);
            if (registeredImg.empty()) return verificationError("Could not load registered image");

            // 3. Convert Probe (Base64) to Mat
            String base64Data = base64Image.contains(",") ? base64Image.split(",")[1] : base64Image;
            byte[] imageBytes = Base64.getDecoder().decode(base64Data);
            MatOfByte mb = new MatOfByte(imageBytes);
            Mat probeImg = Imgcodecs.imdecode(mb, Imgcodecs.IMREAD_UNCHANGED);
            if (probeImg.empty()) return verificationError("Could not decode camera image");

            // 4. Detect Face in Probe Image (Critical check)
            MatOfRect probeDetections = new MatOfRect();
            faceDetector.detectMultiScale(probeImg, probeDetections);
            Rect[] probeFaces = probeDetections.toArray();
            
            if (probeFaces.length == 0) return verificationError("No face detected in camera");
            
            // 5. Detect Face in Registered Image (to crop just the face)
            // (Assumes registered image is good, but let's be safe)
            MatOfRect regDetections = new MatOfRect();
            faceDetector.detectMultiScale(registeredImg, regDetections);
            Rect[] regFaces = regDetections.toArray();
            if (regFaces.length == 0) return verificationError("Original registered face invalid");

            // 6. Crop and Process Images for Comparison
            // We crop the FIRST valid face found
            Mat face1 = new Mat(registeredImg, regFaces[0]);
            Mat face2 = new Mat(probeImg, probeFaces[0]);

            // Convert to HSV color space (better for histogram comparison than RGB)
            Mat hsv1 = new Mat();
            Mat hsv2 = new Mat();
            Imgproc.cvtColor(face1, hsv1, Imgproc.COLOR_BGR2HSV);
            Imgproc.cvtColor(face2, hsv2, Imgproc.COLOR_BGR2HSV);

            // Calculate Histograms
            Mat hist1 = new Mat();
            Mat hist2 = new Mat();
            
            // Histogram parameters
            MatOfInt histSize = new MatOfInt(50, 60);
            MatOfFloat ranges = new MatOfFloat(0, 180, 0, 256);
            MatOfInt channels = new MatOfInt(0, 1);
            
            Imgproc.calcHist(java.util.Collections.singletonList(hsv1), channels, new Mat(), hist1, histSize, ranges);
            Imgproc.calcHist(java.util.Collections.singletonList(hsv2), channels, new Mat(), hist2, histSize, ranges);
            
            // Normalize histograms
            Core.normalize(hist1, hist1, 0, 1, Core.NORM_MINMAX);
            Core.normalize(hist2, hist2, 0, 1, Core.NORM_MINMAX);

            // Compare Histograms
            // Method 3 = CV_COMP_BHATTACHARYYA (Low score = good match)
            double distance = Imgproc.compareHist(hist1, hist2, Imgproc.CV_COMP_BHATTACHARYYA);
            
            // Convert distance to confidence (0 -> 100%, 1 -> 0%)
            // A good match is usually < 0.3 or 0.4
            double confidence = 1.0 - distance;
            
            log.info("Face Verification Score (Bhattacharyya): Distance={}, Confidence={}", String.format("%.4f", distance), String.format("%.2f", confidence * 100));

            // Verify
            boolean verified = distance < MATCH_THRESHOLD;

            return FaceVerificationResponse.builder()
                    .verified(verified)
                    .confidence(confidence)
                    .message(verified ? "Face Verified" : "Face verification failed. Please try again.")
                    .voterId(voterId)
                    .build();

        } catch (Exception e) {
            log.error("Error verifying face: ", e);
            return verificationError("System error: " + e.getMessage());
        }
    }

    private FaceVerificationResponse verificationError(String message) {
        return FaceVerificationResponse.builder()
                .verified(false)
                .confidence(0.0)
                .message(message)
                .build();
    }
}
