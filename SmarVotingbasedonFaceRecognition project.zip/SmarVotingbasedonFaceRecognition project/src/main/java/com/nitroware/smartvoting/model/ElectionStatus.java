package com.nitroware.smartvoting.model;

public enum ElectionStatus {
    UPCOMING,    // Election scheduled but not started
    ACTIVE,      // Voting is currently open
    COMPLETED,   // Voting has ended
    CANCELLED    // Election was cancelled
}
