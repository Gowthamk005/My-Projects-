package com.nitroware.smartvoting.controller;

import com.nitroware.smartvoting.blockchain.BlockchainService;
import com.nitroware.smartvoting.blockchain.BlockchainStats;
import com.nitroware.smartvoting.dto.BlockchainTransaction;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST API Controller for Blockchain operations
 */
@RestController
@RequestMapping("/api/blockchain")
@RequiredArgsConstructor
public class BlockchainController {

    private final BlockchainService blockchainService;

    /**
     * Get blockchain network statistics
     */
    @GetMapping("/stats")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BlockchainStats> getBlockchainStats() {
        return ResponseEntity.ok(blockchainService.getBlockchainStats());
    }

    /**
     * Get recent blockchain transactions
     */
    @GetMapping("/transactions")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<BlockchainTransaction>> getRecentTransactions(
            @RequestParam(defaultValue = "20") int limit) {
        return ResponseEntity.ok(blockchainService.getRecentTransactions(limit));
    }

    /**
     * Get transaction by hash
     */
    @GetMapping("/transactions/{txHash}")
    public ResponseEntity<?> getTransaction(@PathVariable String txHash) {
        return blockchainService.getTransaction(txHash)
                .map(tx -> ResponseEntity.ok(tx))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Verify a transaction exists on blockchain
     */
    @GetMapping("/verify/{txHash}")
    public ResponseEntity<Map<String, Object>> verifyTransaction(@PathVariable String txHash) {
        boolean exists = blockchainService.verifyTransaction(txHash);
        return ResponseEntity.ok(Map.of(
            "transactionHash", txHash,
            "verified", exists,
            "message", exists ? "Transaction verified on blockchain" : "Transaction not found"
        ));
    }

    /**
     * Get voter's blockchain transactions
     */
    @GetMapping("/voter/{voterId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'VOTER')")
    public ResponseEntity<List<BlockchainTransaction>> getVoterTransactions(@PathVariable String voterId) {
        return ResponseEntity.ok(blockchainService.getVoterTransactions(voterId));
    }

    /**
     * Get blockchain connection status
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getBlockchainStatus() {
        return ResponseEntity.ok(Map.of(
            "connected", blockchainService.isConnected(),
            "enabled", blockchainService.isEnabled(),
            "mode", blockchainService.isConnected() ? "GANACHE" : "SIMULATED",
            "message", blockchainService.isConnected() 
                ? "Connected to Ganache blockchain" 
                : "Running in simulated blockchain mode"
        ));
    }
}
