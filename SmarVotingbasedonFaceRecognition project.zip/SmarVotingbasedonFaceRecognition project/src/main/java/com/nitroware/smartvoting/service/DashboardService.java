package com.nitroware.smartvoting.service;

import com.nitroware.smartvoting.dto.DashboardStats;
import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final VoterRepository voterRepository;
    private final ElectionRepository electionRepository;
    private final VoteRepository voteRepository;
    private final FaceVerificationLogRepository faceVerificationLogRepository;

    public DashboardStats getDashboardStats() {
        long totalVoters = voterRepository.count();
        long verifiedVoters = voterRepository.countByStatus(VoterStatus.APPROVED);
        long pendingVoters = voterRepository.countByStatus(VoterStatus.PENDING);
        long activeElections = electionRepository.countByStatus(ElectionStatus.ACTIVE);
        long upcomingElections = electionRepository.countByStatus(ElectionStatus.UPCOMING);
        long completedElections = electionRepository.countByStatus(ElectionStatus.COMPLETED);
        long totalVotesCast = voteRepository.count();
        long faceVerificationsSuccess = faceVerificationLogRepository.countSuccessfulVerifications();
        long faceVerificationsFailed = faceVerificationLogRepository.countFailedVerifications();

        double voterTurnout = verifiedVoters > 0 
                ? ((double) voterRepository.countVotersWhoVoted() / verifiedVoters) * 100 
                : 0;

        return DashboardStats.builder()
                .totalVoters(totalVoters)
                .verifiedVoters(verifiedVoters)
                .pendingVoters(pendingVoters)
                .activeElections(activeElections)
                .upcomingElections(upcomingElections)
                .completedElections(completedElections)
                .totalVotesCast(totalVotesCast)
                .faceVerificationsSuccess(faceVerificationsSuccess)
                .faceVerificationsFailed(faceVerificationsFailed)
                .voterTurnoutPercentage(voterTurnout)
                .build();
    }
}
