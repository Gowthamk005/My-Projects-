package com.nitroware.smartvoting.controller;

import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.Voter;
import com.nitroware.smartvoting.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final VoterService voterService;
    private final ElectionService electionService;
    private final CandidateService candidateService;
    private final DashboardService dashboardService;

    // Dashboard
    @GetMapping("/dashboard")
    public ResponseEntity<DashboardStats> getDashboardStats() {
        return ResponseEntity.ok(dashboardService.getDashboardStats());
    }

    // Voter Management
    @GetMapping("/voters")
    public ResponseEntity<List<VoterResponse>> getAllVoters() {
        List<VoterResponse> voters = voterService.getAllVoters().stream()
                .map(voterService::mapToVoterResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(voters);
    }

    @GetMapping("/voters/pending")
    public ResponseEntity<List<VoterResponse>> getPendingVoters() {
        List<VoterResponse> voters = voterService.getPendingVoters().stream()
                .map(voterService::mapToVoterResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(voters);
    }

    @GetMapping("/voters/{id}")
    public ResponseEntity<VoterResponse> getVoter(@PathVariable Long id) {
        Voter voter = voterService.getVoterById(id);
        if (voter != null) {
            return ResponseEntity.ok(voterService.mapToVoterResponse(voter));
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/voters/{id}/approve")
    public ResponseEntity<ApiResponse<VoterResponse>> approveVoter(@PathVariable Long id) {
        return ResponseEntity.ok(voterService.approveVoter(id));
    }

    @PostMapping("/voters/{id}/reject")
    public ResponseEntity<ApiResponse<VoterResponse>> rejectVoter(
            @PathVariable Long id,
            @RequestBody Map<String, String> payload) {
        String reason = payload.getOrDefault("reason", "No reason provided");
        return ResponseEntity.ok(voterService.rejectVoter(id, reason));
    }

    // Election Management
    @GetMapping("/elections")
    public ResponseEntity<List<ElectionResponse>> getAllElections() {
        return ResponseEntity.ok(electionService.getAllElections());
    }

    @GetMapping("/elections/{id}")
    public ResponseEntity<ElectionResponse> getElection(@PathVariable Long id) {
        return ResponseEntity.ok(electionService.getElectionById(id));
    }

    @PostMapping("/elections")
    public ResponseEntity<ApiResponse<ElectionResponse>> createElection(
            @Valid @RequestBody ElectionRequest request) {
        return ResponseEntity.ok(electionService.createElection(request));
    }

    @PutMapping("/elections/{id}")
    public ResponseEntity<ApiResponse<ElectionResponse>> updateElection(
            @PathVariable Long id,
            @Valid @RequestBody ElectionRequest request) {
        return ResponseEntity.ok(electionService.updateElection(id, request));
    }

    @DeleteMapping("/elections/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteElection(@PathVariable Long id) {
        return ResponseEntity.ok(electionService.deleteElection(id));
    }

    @PostMapping("/elections/{id}/start")
    public ResponseEntity<ApiResponse<ElectionResponse>> startElection(@PathVariable Long id) {
        return ResponseEntity.ok(electionService.startElection(id));
    }

    @PostMapping("/elections/{id}/end")
    public ResponseEntity<ApiResponse<ElectionResponse>> endElection(@PathVariable Long id) {
        return ResponseEntity.ok(electionService.endElection(id));
    }

    @PostMapping("/elections/{id}/publish-results")
    public ResponseEntity<ApiResponse<ElectionResponse>> publishResults(@PathVariable Long id) {
        return ResponseEntity.ok(electionService.publishResults(id));
    }

    // Candidate Management
    @GetMapping("/candidates")
    public ResponseEntity<List<CandidateResponse>> getAllCandidates() {
        return ResponseEntity.ok(candidateService.getAllCandidates());
    }

    @GetMapping("/elections/{electionId}/candidates")
    public ResponseEntity<List<CandidateResponse>> getCandidatesByElection(@PathVariable Long electionId) {
        return ResponseEntity.ok(candidateService.getCandidatesByElection(electionId));
    }

    @PostMapping("/candidates")
    public ResponseEntity<ApiResponse<CandidateResponse>> createCandidate(
            @Valid @RequestBody CandidateRequest request) {
        return ResponseEntity.ok(candidateService.createCandidate(request));
    }

    @PutMapping("/candidates/{id}")
    public ResponseEntity<ApiResponse<CandidateResponse>> updateCandidate(
            @PathVariable Long id,
            @Valid @RequestBody CandidateRequest request) {
        return ResponseEntity.ok(candidateService.updateCandidate(id, request));
    }

    @PostMapping("/candidates/{id}/photo")
    public ResponseEntity<ApiResponse<CandidateResponse>> uploadCandidatePhoto(
            @PathVariable Long id,
            @RequestParam("photo") MultipartFile photo) {
        return ResponseEntity.ok(candidateService.uploadCandidatePhoto(id, photo));
    }

    @DeleteMapping("/candidates/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteCandidate(@PathVariable Long id) {
        return ResponseEntity.ok(candidateService.deleteCandidate(id));
    }

    // Results
    @GetMapping("/elections/{id}/results")
    public ResponseEntity<List<CandidateResponse>> getElectionResults(@PathVariable Long id) {
        return ResponseEntity.ok(electionService.getElectionResults(id));
    }
}
