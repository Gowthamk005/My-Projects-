package com.nitroware.smartvoting.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginResponse {
    private String token;
    private String email;
    private String role;
    private String fullName;
    private Long userId;
    private boolean faceRegistered;
    private String message;
}
