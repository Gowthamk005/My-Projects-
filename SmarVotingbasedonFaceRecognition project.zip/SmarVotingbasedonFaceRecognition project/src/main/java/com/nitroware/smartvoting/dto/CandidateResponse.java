package com.nitroware.smartvoting.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CandidateResponse {
    private Long id;
    private String name;
    private String partyName;
    private String partySymbol;
    private String photoPath;
    private String biography;
    private String qualification;
    private Integer age;
    private int voteCount;
    private double votePercentage;
    private String constituency;
    private Long electionId;
    private String electionTitle;
}
