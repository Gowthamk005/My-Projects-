package com.nitroware.smartvoting.dto;

import com.nitroware.smartvoting.model.ElectionStatus;
import com.nitroware.smartvoting.model.ElectionType;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ElectionResponse {
    private Long id;
    private String title;
    private String description;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private ElectionStatus status;
    private ElectionType type;
    private String constituency;
    private int totalVotes;
    private int candidateCount;
    private boolean resultsPublished;
    private List<CandidateResponse> candidates;
}
