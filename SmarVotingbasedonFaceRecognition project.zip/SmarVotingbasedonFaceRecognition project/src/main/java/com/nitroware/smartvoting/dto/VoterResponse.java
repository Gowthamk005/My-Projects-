package com.nitroware.smartvoting.dto;

import com.nitroware.smartvoting.model.VoterStatus;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoterResponse {
    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private String fullName;
    private String phone;
    private String voterId;
    private String aadhaarNumber;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String city;
    private String state;
    private String pincode;
    private boolean faceRegistered;
    private boolean verified;
    private boolean hasVoted;
    private VoterStatus status;
    private String faceImagePath;
}
