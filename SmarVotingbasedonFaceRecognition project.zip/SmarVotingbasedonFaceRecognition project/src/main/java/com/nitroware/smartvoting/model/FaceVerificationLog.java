package com.nitroware.smartvoting.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "face_verification_logs")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FaceVerificationLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "voter_id")
    private Voter voter;

    @Column(nullable = false)
    private LocalDateTime attemptTime;

    @Column(nullable = false)
    private boolean successful;

    private Double confidenceScore;

    private String ipAddress;

    private String deviceInfo;

    private String failureReason;

    @Enumerated(EnumType.STRING)
    private VerificationType verificationType;

    @PrePersist
    protected void onCreate() {
        attemptTime = LocalDateTime.now();
    }
}
