package com.nitroware.smartvoting.config;

import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ElectionRepository electionRepository;
    private final CandidateRepository candidateRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        initializeAdminUser();
        initializeSampleElection();
    }

    private void initializeAdminUser() {
        if (!userRepository.existsByEmail("admin@smartvoting.com")) {
            User admin = User.builder()
                    .email("admin@smartvoting.com")
                    .password(passwordEncoder.encode("admin123"))
                    .firstName("System")
                    .lastName("Administrator")
                    .phone("0000000000")
                    .role(Role.ADMIN)
                    .enabled(true)
                    .accountNonLocked(true)
                    .build();
            
            userRepository.save(admin);
            log.info("✅ Admin user created: admin@smartvoting.com / admin123");
        }
    }

    private void initializeSampleElection() {
        if (electionRepository.count() == 0) {
            // Create a sample upcoming election
            Election election = Election.builder()
                    .title("General Election 2026")
                    .description("National General Election for selecting representatives to the Parliament.")
                    .startDate(LocalDateTime.now().plusDays(1))
                    .endDate(LocalDateTime.now().plusDays(8))
                    .type(ElectionType.GENERAL)
                    .status(ElectionStatus.UPCOMING)
                    .constituency("National")
                    .resultsPublished(false)
                    .build();

            election = electionRepository.save(election);

            // Add sample candidates
            Candidate candidate1 = Candidate.builder()
                    .name("John Smith")
                    .partyName("Progressive Party")
                    .partySymbol("🌟")
                    .biography("Experienced leader with 15 years in public service.")
                    .qualification("Masters in Public Administration")
                    .age(52)
                    .election(election)
                    .constituency("National")
                    .voteCount(0)
                    .active(true)
                    .build();

            Candidate candidate2 = Candidate.builder()
                    .name("Sarah Johnson")
                    .partyName("People's Alliance")
                    .partySymbol("🌺")
                    .biography("Advocate for social justice and economic reform.")
                    .qualification("PhD in Economics")
                    .age(45)
                    .election(election)
                    .constituency("National")
                    .voteCount(0)
                    .active(true)
                    .build();

            Candidate candidate3 = Candidate.builder()
                    .name("Michael Chen")
                    .partyName("Unity Front")
                    .partySymbol("🕊️")
                    .biography("Technology entrepreneur focused on modernization.")
                    .qualification("MBA from Harvard Business School")
                    .age(48)
                    .election(election)
                    .constituency("National")
                    .voteCount(0)
                    .active(true)
                    .build();

            candidateRepository.save(candidate1);
            candidateRepository.save(candidate2);
            candidateRepository.save(candidate3);

            log.info("✅ Sample election created: {}", election.getTitle());
        }
    }
}
