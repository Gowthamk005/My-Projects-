package com.nitroware.smartvoting.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "votes", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"voter_id", "election_id"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "voter_id", nullable = false)
    private Voter voter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "election_id", nullable = false)
    private Election election;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidate_id", nullable = false)
    private Candidate candidate;

    @Column(nullable = false)
    private LocalDateTime votedAt;

    // For audit trail (encrypted/hashed for privacy)
    private String voteHash;

    private String ipAddress;

    private String deviceInfo;

    // Face verification confidence score
    private Double faceMatchConfidence;

    // Blockchain transaction details
    @Column(length = 100)
    private String blockchainTxHash;
    
    private Long blockNumber;

    @PrePersist
    protected void onCreate() {
        votedAt = LocalDateTime.now();
    }
}
