package com.nitroware.smartvoting.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoteRequest {

    @NotNull(message = "Election ID is required")
    private Long electionId;

    @NotNull(message = "Candidate ID is required")
    private Long candidateId;

    // Face image for verification (Base64 encoded)
    @NotBlank(message = "Face image is required for verification")
    private String faceImage;
}
