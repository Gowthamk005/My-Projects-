package com.nitroware.smartvoting.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DashboardStats {
    private long totalVoters;
    private long verifiedVoters;
    private long pendingVoters;
    private long activeElections;
    private long upcomingElections;
    private long completedElections;
    private long totalVotesCast;
    private long faceVerificationsSuccess;
    private long faceVerificationsFailed;
    private double voterTurnoutPercentage;
}
