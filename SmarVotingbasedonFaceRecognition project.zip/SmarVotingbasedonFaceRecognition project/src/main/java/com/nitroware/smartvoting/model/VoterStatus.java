package com.nitroware.smartvoting.model;

public enum VoterStatus {
    PENDING,      // Awaiting admin verification
    APPROVED,     // Verified and can vote
    REJECTED,     // Rejected by admin
    SUSPENDED     // Temporarily suspended
}
