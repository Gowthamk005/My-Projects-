package com.nitroware.smartvoting.repository;

import com.nitroware.smartvoting.model.FaceVerificationLog;
import com.nitroware.smartvoting.model.VerificationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface FaceVerificationLogRepository extends JpaRepository<FaceVerificationLog, Long> {
    
    List<FaceVerificationLog> findByVoterId(Long voterId);
    
    List<FaceVerificationLog> findBySuccessful(boolean successful);
    
    List<FaceVerificationLog> findByVerificationType(VerificationType type);
    
    @Query("SELECT f FROM FaceVerificationLog f WHERE f.voter.id = :voterId AND f.attemptTime > :since")
    List<FaceVerificationLog> findRecentAttempts(@Param("voterId") Long voterId, 
                                                  @Param("since") LocalDateTime since);
    
    @Query("SELECT COUNT(f) FROM FaceVerificationLog f WHERE f.voter.id = :voterId AND f.successful = false AND f.attemptTime > :since")
    long countFailedAttemptsRecently(@Param("voterId") Long voterId, 
                                     @Param("since") LocalDateTime since);
    
    @Query("SELECT COUNT(f) FROM FaceVerificationLog f WHERE f.successful = true")
    long countSuccessfulVerifications();
    
    @Query("SELECT COUNT(f) FROM FaceVerificationLog f WHERE f.successful = false")
    long countFailedVerifications();
}
