package com.nitroware.smartvoting.service;

import com.nitroware.smartvoting.dto.*;
import com.nitroware.smartvoting.model.*;
import com.nitroware.smartvoting.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class VoterService {

    private final VoterRepository voterRepository;
    private final UserRepository userRepository;
    private final FaceRecognitionService faceRecognitionService;
    private final FaceVerificationLogRepository faceVerificationLogRepository;

    private final VoteRepository voteRepository;

    @Value("${app.upload.face-images-dir}")
    private String faceImagesDir;

    public List<Voter> getAllVoters() {
        return voterRepository.findAll();
    }
    
    public List<Vote> getVotingHistory(Long voterId) {
        return voteRepository.findByVoterId(voterId);
    }

    public Voter getVoterById(Long id) {
        return voterRepository.findById(id).orElse(null);
    }

    public Voter getVoterByUserId(Long userId) {
        return voterRepository.findByUserId(userId).orElse(null);
    }

    public Voter getVoterByEmail(String email) {
        return voterRepository.findByUserEmail(email).orElse(null);
    }

    public List<Voter> getVotersByStatus(VoterStatus status) {
        return voterRepository.findByStatus(status);
    }

    public List<Voter> getPendingVoters() {
        return voterRepository.findByStatus(VoterStatus.PENDING);
    }

    @Transactional
    public ApiResponse<VoterResponse> registerFace(Long voterId, MultipartFile faceImage) {
        try {
            Voter voter = voterRepository.findById(voterId)
                    .orElseThrow(() -> new RuntimeException("Voter not found"));

            // Save face image
            String fileName = "face_" + voter.getVoterId() + "_" + UUID.randomUUID() + ".jpg";
            Path uploadPath = Paths.get(faceImagesDir);
            
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(fileName);
            Files.copy(faceImage.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            // Register face with face recognition service
            FaceVerificationResponse faceResponse = faceRecognitionService.registerFace(
                    voter.getVoterId(), 
                    filePath.toString()
            );

            if (faceResponse.isVerified()) {
                voter.setFaceImagePath(filePath.toString());
                voter.setFaceEncodingPath(faceImagesDir + "/encodings/" + voter.getVoterId() + ".json");
                voter.setFaceRegistered(true);
                voterRepository.save(voter);

                // Log successful registration
                logFaceVerification(voter, true, faceResponse.getConfidence(), 
                        VerificationType.REGISTRATION, null);

                return ApiResponse.success(mapToVoterResponse(voter), 
                        "Face registered successfully. Awaiting admin verification.");
            } else {
                // Log failed registration
                logFaceVerification(voter, false, 0.0, 
                        VerificationType.REGISTRATION, faceResponse.getMessage());
                        
                return ApiResponse.error("Face registration failed: " + faceResponse.getMessage());
            }

        } catch (IOException e) {
            log.error("Error saving face image: ", e);
            return ApiResponse.error("Failed to save face image: " + e.getMessage());
        } catch (Exception e) {
            log.error("Error registering face: ", e);
            return ApiResponse.error("Face registration failed: " + e.getMessage());
        }
    }

    @Transactional
    public ApiResponse<VoterResponse> registerFaceBase64(Long voterId, String base64Image) {
        try {
            Voter voter = voterRepository.findById(voterId)
                    .orElseThrow(() -> new RuntimeException("Voter not found"));

            // Decode base64 image
            String base64Data = base64Image;
            if (base64Image.contains(",")) {
                base64Data = base64Image.split(",")[1];
            }
            byte[] imageBytes = Base64.getDecoder().decode(base64Data);

            // Save face image
            String fileName = "face_" + voter.getVoterId() + "_" + UUID.randomUUID() + ".jpg";
            Path uploadPath = Paths.get(faceImagesDir);
            
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(fileName);
            Files.write(filePath, imageBytes);

            // Register face with face recognition service
            FaceVerificationResponse faceResponse = faceRecognitionService.registerFace(
                    voter.getVoterId(), 
                    filePath.toString()
            );

            if (faceResponse.isVerified()) {
                voter.setFaceImagePath(filePath.toString());
                voter.setFaceEncodingPath(faceImagesDir + "/encodings/" + voter.getVoterId() + ".json");
                voter.setFaceRegistered(true);
                voterRepository.save(voter);

                logFaceVerification(voter, true, faceResponse.getConfidence(), 
                        VerificationType.REGISTRATION, null);

                return ApiResponse.success(mapToVoterResponse(voter), 
                        "Face registered successfully. Awaiting admin verification.");
            } else {
                logFaceVerification(voter, false, 0.0, 
                        VerificationType.REGISTRATION, faceResponse.getMessage());
                        
                return ApiResponse.error("Face registration failed: " + faceResponse.getMessage());
            }

        } catch (Exception e) {
            log.error("Error registering face: ", e);
            return ApiResponse.error("Face registration failed: " + e.getMessage());
        }
    }

    @Transactional
    public FaceVerificationResponse verifyFace(Long voterId, String base64Image) {
        try {
            Voter voter = voterRepository.findById(voterId)
                    .orElseThrow(() -> new RuntimeException("Voter not found"));

            if (!voter.isFaceRegistered()) {
                return FaceVerificationResponse.builder()
                        .verified(false)
                        .message("Face not registered for this voter")
                        .build();
            }

            FaceVerificationResponse response = faceRecognitionService.verifyFace(
                    voter.getVoterId(), 
                    base64Image
            );

            logFaceVerification(voter, response.isVerified(), response.getConfidence(),
                    VerificationType.VOTING, response.isVerified() ? null : response.getMessage());

            return response;

        } catch (Exception e) {
            log.error("Error verifying face: ", e);
            return FaceVerificationResponse.builder()
                    .verified(false)
                    .message("Face verification failed: " + e.getMessage())
                    .build();
        }
    }

    @Transactional
    public ApiResponse<VoterResponse> approveVoter(Long voterId) {
        Voter voter = voterRepository.findById(voterId)
                .orElseThrow(() -> new RuntimeException("Voter not found"));

        if (!voter.isFaceRegistered()) {
            // Allow approval even without face registration for testing purposes
            log.warn("Approving voter {} without face registration", voterId);
            // return ApiResponse.error("Cannot approve voter without face registration");
        }

        voter.setStatus(VoterStatus.APPROVED);
        voter.setVerified(true);
        voterRepository.save(voter);

        return ApiResponse.success(mapToVoterResponse(voter), "Voter approved successfully");
    }

    @Transactional
    public ApiResponse<VoterResponse> rejectVoter(Long voterId, String reason) {
        Voter voter = voterRepository.findById(voterId)
                .orElseThrow(() -> new RuntimeException("Voter not found"));

        voter.setStatus(VoterStatus.REJECTED);
        voter.setVerified(false);
        voter.setRejectionReason(reason);
        voterRepository.save(voter);

        return ApiResponse.success(mapToVoterResponse(voter), "Voter rejected");
    }

    private void logFaceVerification(Voter voter, boolean success, double confidence, 
                                     VerificationType type, String failureReason) {
        FaceVerificationLog log = FaceVerificationLog.builder()
                .voter(voter)
                .successful(success)
                .confidenceScore(confidence)
                .verificationType(type)
                .failureReason(failureReason)
                .build();
        faceVerificationLogRepository.save(log);
    }

    public VoterResponse mapToVoterResponse(Voter voter) {
        return VoterResponse.builder()
                .id(voter.getId())
                .email(voter.getUser().getEmail())
                .firstName(voter.getUser().getFirstName())
                .lastName(voter.getUser().getLastName())
                .fullName(voter.getUser().getFullName())
                .phone(voter.getUser().getPhone())
                .voterId(voter.getVoterId())
                .aadhaarNumber(voter.getAadhaarNumber())
                .dateOfBirth(voter.getDateOfBirth())
                .gender(voter.getGender())
                .address(voter.getAddress())
                .city(voter.getCity())
                .state(voter.getState())
                .pincode(voter.getPincode())
                .faceRegistered(voter.isFaceRegistered())
                .verified(voter.isVerified())
                .hasVoted(voter.isHasVoted())
                .status(voter.getStatus())
                .faceImagePath(voter.getFaceImagePath())
                .build();
    }
}
