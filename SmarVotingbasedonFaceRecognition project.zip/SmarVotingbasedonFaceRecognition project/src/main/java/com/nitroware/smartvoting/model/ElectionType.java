package com.nitroware.smartvoting.model;

public enum ElectionType {
    GENERAL,       // General elections
    STATE,         // State level
    LOCAL,         // Local body elections
    PARLIAMENTARY, // Parliamentary elections
    MUNICIPAL      // Municipal elections
}
