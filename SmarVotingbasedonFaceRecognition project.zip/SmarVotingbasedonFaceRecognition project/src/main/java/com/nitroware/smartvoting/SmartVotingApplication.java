package com.nitroware.smartvoting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class SmartVotingApplication {

    public static void main(String[] args) {
        var context = SpringApplication.run(SmartVotingApplication.class, args);
        String port = context.getEnvironment().getProperty("server.port", "8080");
        
        System.out.println("""
            
            ╔══════════════════════════════════════════════════════════════╗
            ║                                                              ║
            ║   🗳️  SMART VOTING SYSTEM - Face Recognition Based          ║
            ║                                                              ║
            ║   Application started successfully!                          ║
            ║   Access: http://localhost:%s                              ║
            ║   H2 Console: http://localhost:%s/h2-console               ║
            ║                                                              ║
            ║   Default Admin Credentials:                                 ║
            ║   Username: admin@smartvoting.com                            ║
            ║   Password: admin123                                         ║
            ║                                                              ║
            ╚══════════════════════════════════════════════════════════════╝
            """.formatted(port, port));
    }
}
